<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author lainme <lainme993@gmail.com>
 * @author Errol <errol@hotmail.com>
 * @author phy25 <git@phy25.com>
 */
$lang['domain']                = '登录域';
$lang['authpwdexpire']         = '您的密码将在 %d 天内过期，请尽快更改。';
$lang['passchangefail']        = '密码更改失败。是不是密码规则不符合？';
$lang['userchangefail']        = '更改用户属性失败。或许您的帐号没有做此更改的权限？';
$lang['connectfail']           = '无法连接到Active Directory服务器。';
