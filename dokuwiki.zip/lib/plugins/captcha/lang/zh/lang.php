<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Andreas Gohr <andi@splitbrain.org>
 * @author lainme <lainme993@gmail.com>
 */
$lang['testfailed']            = '抱歉，您输入的验证码不正确。';
$lang['fillcaptcha']           = '请在输入框中填入验证码以证明您不是机器人。';
$lang['fillmath']              = '请填入算式的结果以证明您不是机器人。';
$lang['soundlink']             = '如果您无法阅读图片中的字母，请下载此 .wav 文件。';
$lang['honeypot']              = '请将此区域留空：';
