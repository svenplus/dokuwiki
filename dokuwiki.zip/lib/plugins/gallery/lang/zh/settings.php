<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author RainSlide <RainSlide@outlook.com>
 * @author oott123 <ip.192.168.1.1@qq.com>
 */
$lang['thumbnail_width']       = '缩略图宽度';
$lang['thumbnail_height']      = '缩略图高度';
$lang['image_width']           = '图片宽度';
$lang['image_height']          = '图片高度';
$lang['cols']                  = '每行图片数量';
$lang['sort']                  = '图片排序方式';
$lang['sort_o_file']           = '按文件名';
$lang['sort_o_mod']            = '按文件时间';
$lang['sort_o_date']           = '按 EXIF 时间';
$lang['sort_o_title']          = '按 EXIT 标题';
$lang['options']               = '其他相册默认选项';
